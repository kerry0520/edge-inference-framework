# 平台(如果交叉编译请再附上交叉编译目标平台)

Windows x64，本机MSVC构建，CPU后端，monolithic shared（MNN_SEP_BUILD=OFF）。既有Qwen3-0.6B MNN资源；CPU/high precision、greedy、thread_num=1、reuse_kv=true、prompt_cache=true、async=false、chunk=0。完整Jinja模板来自模型llm_config.json，context.enable_thinking=false；没有简化模板。无speculative decoding、disk prefix或erase/reserve操作。

# Github版本

`97715f88fbd7c82ab86d240d27c403930e739799`。

复现关联已合入的[prompt cache PR #4330](https://github.com/alibaba/MNN/pull/4330)。本地检索prompt-cache/cached-text/thinking-cache相关记录后，暂未找到同一具体前缀错配报告；如有重复请告知。

为排除独立tokenizer修复的影响，另用纯官方版本复跑两项缓存场景：完整当前共享库构建最初含独立tokenizer改动，随后确认其相对97715f8仅差tokenizer.cpp一文件，将该文件精确还原为官方Git blob并重编/重链；当前316对象中其余315项不变，没有Windows affinity实验对象。实际加载DLL SHA256：`db19ad7d6b08acbe42684a9ccb48952d719991f932cfeaf8a83d7f9a09a0a5aa`。这是来源可核对的纯官方源码对象组合，不是第二次clean全量构建。两项纯官方结果均与此前结果逐token一致。

# 编译方式

MSVC x64 Release，Ninja；主要CMake参数：

```text
-DCMAKE_BUILD_TYPE=Release -DCMAKE_EXPORT_COMPILE_COMMANDS=ON
-DMNN_BUILD_SHARED_LIBS=ON -DMNN_SEP_BUILD=OFF -DMNN_BUILD_LLM=ON
-DMNN_BUILD_LLM_OMNI=OFF -DMNN_BUILD_TOOLS=OFF -DMNN_BUILD_TEST=OFF
-DMNN_OPENCL=OFF -DMNN_VULKAN=OFF -DMNN_AVX512=OFF -DMNN_AVX512_VNNI=OFF
-DLLM_SUPPORT_HTTP_RESOURCE=OFF
cmake --build <BUILD> --target MNN tokenizer_demo -j 6
```

官方tokenizer对象还原使用该构建的compile_commands.json原shared flags，其他315个对象不变。DLL导出仍为相同1092名称。探针只通过公开llm.hpp调用API，链接shared import library，不需要内部接口导出；实际GetModuleFileNameW加载路径已核对。复现探针源码、参数化编译/配置/运行方式见附件README。

# 编译日志

附件build-logs-sanitized.zip包含完整已有CMake配置/构建stdout/stderr、官方tokenizer还原编译/链接/导出日志及两项纯官方运行日志；仅替换本机个人路径。配置、编译、链接均实际exit0，配置有CMake最低版本和ASM policy警告，没有将其省略为“无警告”。探针的两个模型进程各执行两次response(ChatMessages)，均实际exit0。

## 复现与实际结果

先从全新Llm实例开始，以完整消息列表调用response(ChatMessages)。首轮结束后将`getContext()->generate_str`作为assistant消息追加，再追加第二个user问题，仍传完整消息列表。完整render文本和token向量都由实际`apply_chat_template()`/`tokenizer_encode()`得到。附件probe.cpp为实际编译运行的同一源码，未override embedding/forwardRaw。

1. **预算截断、非EOS**：首问`What is 2 + 10? Answer only with the number.`，首轮max_new_tokens=1。输入27tokens，输出`[17]`，状态MAX_TOKENS_FINISHED；previous=all_seq_len=28、history长度28。第二问为`What was my previous question? Give a short answer.`，max_new_tokens=1。
2. **自然EOS**：首问`Reply with exactly the word hello.`，首轮max_new_tokens=64。输入19tokens，实际输出`[9707, 0, 151645]`，最后151645为stop，状态NORMAL_FINISHED；previous=all_seq_len=21、history长度22。第二问相同。

|纯官方缓存场景|旧previous|旧history长度|第二轮完整F长度|缓存分支实际追加delta长度|推导保留旧KV+delta长度（不含二轮decode）|相对F首差，0-based|
|---|---:|---:|---:|---:|---:|---|
|预算截断非EOS|28|28|49|23|51|23：旧151667，完整F为17|
|自然EOS|21|22|42|23|44|15：旧151667，完整F为9707|

两项实际cache日志的token_split分别为26/19，delta都23；公开history的新增输入也逐ID等于所记录的F[token_split:]。首轮模板在assistant生成位置有`<think>\n\n</think>\n\n`，但二轮完整模板中的历史assistant为`2`或`Hello!`，不保留此前相同的thinking前缀。两个首差都位于这部分模板变化，**不是仅自然EOS导致**。

完整tokens/render/state、模型四文件SHA和完整Jinja见附件；当前带配置/状态守卫的分析器对原始两份纯官方stdout校验40项，实际exit0。另有14个离线坏配置/history分析负例与4个prepare负例均非零拒绝，不为打包重跑模型。四个模型文件的身份为：

```text
llm.mnn          461520 bytes   d426c65a5159c938ccc237cdfbd982137f276804f27b414ca0ecf3fc0a660f8c
llm.mnn.weight   450810338 bytes 953afb7e0165818add34a7a6caf0af5d0ed9428da102eb22c9b98ee9da292e9f
tokenizer.txt    3496630 bytes  e8ab663d07ee45b4448db392d65b4e3b2d382489083157e0debd300e4cb31401
llm_config.json  4907 bytes     996215c9f9c5b3aee473db186c15e05b179105be9a80ef94b44f1577ea48528a
```

## 预期与证据边界

希望确认的契约：prompt_cache复用后保留的条件token序列，是否应与同一ChatMessages完整渲染的tokens一致？还是缓存有意保留旧内部reasoning，而完整模板会strip/省略这部分，因此允许两种路径条件序列不同？固定源码的updateCachedPromptText()/syncPromptCache()调用stripThinkBlocks，可能体现后一种设计取舍，需要维护者确认，不能由本报告直接认定。

本例enable_thinking=false，首轮生成位置仅有模板添加的**空thinking block**，仍可看到差异；cap非EOS也能出现，因此既不要求模型生成实际reasoning，也不能仅归因自然EOS。若上游契约要求与full-render条件一致，建议不满足条件时安全重放；若差异有意保留，请说明预期行为及缓存关闭/混合入口应如何保持语义。

本报告**没有直接读取KV张量，也没有插桩每次成功forward**。K的身份依据公开previous/all_seq_len/history/output及固定普通同步AR源码推导：generate(vector)在forward前写输入history；AR先写采样token，stop时break而不forward，非stop即使是预算最后一项仍forward。因此cap的末项17应纳入物理推导，不能一律丢掉最后输出；EOS末项151645不应纳入物理推导，但仍留在公开history。两项从空状态开始、无取消/失败/投机/reserve/disk、首轮完成状态和计数均符合这些前提。

这个推导不能泛化成多轮`history[:previous]`：EOS会留在history中间，后续delta仍追加，索引已不再与物理槽一一对应。

此前另有两项prompt_cache=false的full-prefill对照，对应完整tokens无此差异，但它们使用含独立tokenizer修复的+C库；**本次纯官方仅重跑上表两项缓存场景，不把旧cache-off对照冒称纯官方运行**。没有Android/GPU/linear attention/异步/投机或答案精度、性能结论；也不声称KV张量损坏或已经证明答案错误。Attention数值缩放的另一个待审方向与本次条件token差异是不同问题，本Issue不混入数值修复。

## 想确认的修复方向

希望先确认上述差异是否符合上游prompt-cache设计，再决定是否需要修复及其范围，而非先提交可能改变history语义的大补丁。若上游希望条件序列与full tokens一致，可讨论：

- 保守方向：无法证明完整物理前缀等于新full tokens前缀时，完整重放，接受暂时降低命中；但reset本身不清reserve，需先明确与erase/linear/disk等组合语义。
- 保留复用方向：只在可信的实际forward token身份与F逐项一致时保留整个旧前缀，或另行讨论token LCP。当前文字cache/history计数不是可信身份日志，需明确EOS、失败和混合入口的失效规则；不应直接用H[:previous]比较冒充验证。

如果prompt-cache仅承诺某些输入/生成方式，或应先做较窄的保守修复，也请维护者指导。当前没有生产修复候选、性能承诺或公开history行为改动。
