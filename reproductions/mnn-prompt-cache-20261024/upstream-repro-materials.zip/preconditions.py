"""Conservative checks for this fixed ordinary-AR reproduction recipe only."""
def reject_unsupported(config):
    if config.get('speculative_type', '') != '':
        raise ValueError('unsupported speculative_type; ordinary AR only')
    if config.get('token_compress', 0) != 0:
        raise ValueError('unsupported token_compress')
    if config.get('ignore_eos', False) is not False:
        raise ValueError('unsupported ignore_eos')
    if config.get('all_logits', False) is not False:
        raise ValueError('unsupported all_logits')
    if config.get('chunk', 0) != 0 or config.get('chunk_limits', []) != []:
        raise ValueError('unsupported chunk/chunk_limits')
    if config.get('is_visual', False) is not False or config.get('is_audio', False) is not False:
        raise ValueError('unsupported multimodal resource')
    if config.get('attention_type', 'full') != 'full':
        raise ValueError('unsupported attention_type; fixed full-attention model only')
    # prefix_cache_path is just a directory, not proof of active disk-cache mode.
    # Disk API use, linear model identity and erase/reserve need recipe/resource
    # provenance; effective JSON cannot prove no such API was called.

def validate_effective(config, expected_jinja):
    reject_unsupported(config)
    expected=dict(backend_type='cpu',precision='high',sampler_type='greedy',thread_num=1,chunk=0)
    for key,value in expected.items():
        if key not in config or config[key] != value:
            raise ValueError('unsupported effective '+key)
    for key,value in [('async',False),('reuse_kv',True),('prompt_cache',True)]:
        if config.get(key) is not value:
            raise ValueError('unsupported effective '+key)
    if config.get('jinja') != expected_jinja:
        raise ValueError('complete Jinja differs from fixed reproduction')
