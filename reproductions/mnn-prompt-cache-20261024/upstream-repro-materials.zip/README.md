# KV prompt-cache 公共API复现材料（本地待审，未发布）

`issue-body.zh.md`是中文Issue草稿。标题建议：`[LLM] prompt_cache 保留的条件 tokens 与完整 Jinja 渲染不同，是否符合预期？`。

材料不包含模型、权重、DLL或EXE，不自动下载。`probe.cpp`与已经在纯官方97715f8共享库上编译运行的探针逐字节相同，SHA见resource-manifest.json。它只包含公开llm.hpp/系统头、调用公开API，不override embedding/forward或导出内部符号。

## 复现步骤

在Windows x64开发者命令行中，以已编译的97715f8 monolithic shared库和已有Qwen3-0.6B MNN模型为输入。建议库、模型和工作目录使用ASCII路径，避开无关的Windows路径编码问题。实际资源名称/哈希列在resource-manifest.json；更换资源可能改变采样结果，不把本材料的精确IDs套到其他模型。

编译（`MNN_SOURCE`为97715f8源码目录，`MNN_BUILD`为MNN.dll/MNN.lib所在目录）：

```cmd
cl /nologo /MD /EHsc /O2 /DUSING_MNN_DLL /source-charset:utf-8 /I%MNN_SOURCE%\include /I%MNN_SOURCE%\transformers\llm\engine\include probe.cpp /Fe:kv_probe.exe %MNN_BUILD%\MNN.lib
```

将自己构建的MNN.dll与kv_probe.exe放在同一个独立目录，保留其来源/哈希；探针会记录实际加载的DLL。上面命令是现有已成功命令的路径参数化版本，不是对外部任意工具链的成功承诺。

配置构造只读取已有model/config.json和model/llm_config.json，写入新目录，不复制模型、不开始推理：

```cmd
python prepare.py --model C:\MODEL --out C:\KVREPRO
```

脚本先拒绝spec/token-compress/ignore_eos/all_logits/chunk_limits等不支持模式，并逐文件检查附件记录的四个模型资源SHA，只接受当前固定full-attention Qwen资源，不默默将未知模型变成“已测”。随后完整保留模型Jinja，只设置context.enable_thinking=false，并设置CPU/high/greedy/thread1、reuse_kv=true、prompt_cache=true、async=false、chunk0。实际已运行模板完整副本在jinja-full.json，禁止替换成一个简化手写模板后仍宣称是同一复现。

分别用新的进程和独立cwd执行两题。以下为PowerShell示例；先将EXE绝对路径赋给`$probeExe`。保存原始退出码，不用`[PASS]`字符串替代：

```powershell
$probeExe = 'C:\BIN\kv_probe.exe'
Set-Location C:\KVREPRO\cap
& $probeExe .\config.json .\runtime-patch.json cap 1>cap.stdout 2>cap.stderr
$LASTEXITCODE | Set-Content cap.exit
Set-Location C:\KVREPRO\eos
& $probeExe .\config.json .\runtime-patch.json eos 1>eos.stdout 2>eos.stderr
$LASTEXITCODE | Set-Content eos.exit
```

Windows PowerShell默认重定向可能改写编码。原采集用Python subprocess二进制stdout/stderr；建议外部复现也用能保留UTF-8原始字节的采集器，或PowerShell7，并保留原件。解析器需要每行JSON/UTF-8，编码转换失败是采集问题，不是模型失败。

解析既有原件，不启动模型：

```cmd
python analyze.py --cap C:\KVREPRO\cap\cap.stdout --eos C:\KVREPRO\eos\eos.stdout --cap-exit 0 --eos-exit 0 --out report.json
```

`--cap-exit/--eos-exit`必须填写实际采集到的值，不能因为示例写0就改写失败。当前分析器强制effective_config的CPU/high/greedy/thread1/reuse/prompt-cache/sync/chunk0、空spec及完整Jinja等前提，并检查before_second与after_first相同、二轮history末段真实等于output、首/二轮物理长度推导和delta。配置或结构不满足即失败，不能用于未知模型或特殊生成路径。

disk-prefix/erase/reserve没有足够的public config getter，linear模型身份也不能仅从一个配置名字证明；这些仍由固定资源和未经修改的probe（没有调用相关API）作为方法前提，不能说JSON审查自动证明了一切。分析器本身不读取运行时模型文件；资源SHA与实际被加载资源身份的对应由采集manifest/recipe另行核验。

当前分析器已对保存的纯官方两份stdout实际执行：**40断言、实际exit0**，见validation-v2/original-analysis.json。另有14个离线受控坏配置/history负例，均实际非零退出；prepare已验证固定资源配置相符，另4个不支持配置/错误资源身份负例均非零拒绝。validation-v2/validation.json共73项通过，无新模型运行。旧28项分析和旧64项validation原件保留，不覆盖、不混称是新守卫。`prepare.py`的配置离线验证不是新增推理验证。

## 附件清单及边界

- probe.cpp、prepare.py、preconditions.py、analyze.py：公开探针、受控配置构造、前提守卫、只读分析器。
- resource-manifest.json：模型四文件size/SHA和纯官方DLL来源描述，无二进制资源。
- jinja-full.json：实际完整Jinja模板及enable_thinking=false。
- cached-*-public-state.json：无个人路径的实际公开状态/完整模板/完整tokens。
- validation-v2/original-analysis.json、validation-v2/validation.json：当前守卫和离线负例核验；不是新模型运行。
- build-logs-sanitized.zip：完整已有CMake/build日志、唯一官方tokenizer对象还原编译/链接/导出日志及两个纯官方运行原始文本；用户路径替换为`<LOCAL>`。目录名明确fresh full build含独立C，随后只还原官方tokenizer对象，**不谎称第二次干净全量master构建**。

Issue首先讨论已有prompt-cache功能的正确性。改动候选、前缀身份跟踪、公开history语义变化、性能收益以及KV-B均不在本材料范围。root审查后决定是否发布，本目录不执行任何外发。

外发时仅使用明确白名单upstream-repro-materials.zip；不要上传整个本地目录（其原始校验/负例stderr为工程留档）。白名单包不含模型、DLL/EXE或个人路径；外发前仍由root复核。
