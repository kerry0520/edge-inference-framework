"""Analyze existing original raw outputs, not direct KV memory."""
import argparse,json,re,sys
from pathlib import Path
from preconditions import validate_effective
p=argparse.ArgumentParser();p.add_argument('--cap',type=Path,required=True);p.add_argument('--eos',type=Path,required=True);p.add_argument('--cap-exit',type=int,required=True);p.add_argument('--eos-exit',type=int,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
checks=[];reports=[]
def check(n,v):checks.append(dict(name=n,passed=bool(v)))
for case,path,exitcode in [('cap',a.cap,a.cap_exit),('eos',a.eos,a.eos_exit)]:
 raw=path.read_bytes();events=[json.loads(l) for l in raw.splitlines() if l.startswith(b'{')]
 configs=[json.loads(x['config']) for x in events if x['kind']=='effective_config']
 if len(configs)!=1:raise ValueError('exactly one effective_config required')
 validate_effective(configs[0],json.loads((Path(__file__).parent/'jinja-full.json').read_text(encoding='utf8')))
 check(case+' validated ordinary sync AR config',True)
 state={x['stage']:x for x in events if x['kind']=='state'};prompt={x['stage']:x for x in events if x['kind']=='prompt'}
 before=state['before_first'];first=state['after_first'];last=state['after_second'];P=prompt['first']['tokens'];F=prompt['second']['tokens'];H=first['history'];out=first['output']
 check(case+' before_second state unchanged',state['before_second']==dict(first,stage='before_second'))
 check(case+' real process exit0',exitcode==0)
 check(case+' empty initial state',before['previous']==before['all_seq_len']==0 and before['history']==[])
 check(case+' first history exactly input plus sampled output',H==P+out)
 check(case+' first completed',first['status'] in [1,2])
 check(case+' output nonempty',len(out)>0)
 # Known exact Qwen resource and ordinary synchronous AR path only.
 # Stop token 151645 is not forwarded; max-budget non-stop token is forwarded.
 check(case+' expected terminal kind',(case=='cap' and first['status']==2 and out==[17]) or (case=='eos' and first['status']==1 and out==[9707,0,151645]))
 K=P+(out[:-1] if case=='eos' else out)
 check(case+' inferred physical length matches public counters',len(K)==first['previous']==first['all_seq_len'])
 check(case+' second extends unchanged public history',last['history'][:len(H)]==H)
 check(case+' second one normal sampled nonEOS',last['status']==2 and len(last['output'])==1 and last['output'][0]!=151645)
 check(case+' second history actual output tail',len(last['output'])>0 and last['history'][-len(last['output']):]==last['output'])
 check(case+' source prompt first complete tokens',len(P)==first['prompt_len'])
 check(case+' second message uses actual response text',prompt['second']['messages']==prompt['first']['messages']+[['assistant',first['text']],['user','What was my previous question? Give a short answer.']])
 delta=last['history'][len(H):-len(last['output'])]
 matches=re.findall(rb'\[prompt_cache\] cached=(\d+), compare=(\d+), common=(\d+), token_split=(\d+), delta=(\d+)',raw)
 check(case+' one real cache-split log',len(matches)==1)
 split=int(matches[0][3]);check(case+' actual delta is logged full suffix',delta==F[split:] and len(delta)==int(matches[0][4]))
 check(case+' second prompt_len actual delta',last['prompt_len']==len(delta))
 submitted=K+delta
 mismatch=next((i for i,(x,y) in enumerate(zip(submitted,F)) if x!=y),min(len(submitted),len(F)))
 check(case+' nonzero prefix mismatch',mismatch<len(K) and submitted[mismatch]!=F[mismatch])
 check(case+' public next physical count matches AR inference',last['previous']==len(submitted)+len(last['output'])==last['all_seq_len'])
 check(case+' two completed actual requests',any(x['kind']=='probe_final' and x['requests']==2 for x in events))
 reports.append(dict(case=case,old_previous=first['previous'],old_history_size=len(H),full_tokens=len(F),delta_tokens=len(delta),retained_plus_delta=len(submitted),first_difference=mismatch,retained_id=submitted[mismatch],full_id=F[mismatch],inferred_old_physical=K,inferred_delta=delta,full_prompt_tokens=F,scope='Public state plus fixed ordinary synchronous AR control-flow inference; not direct KV/forward instrumentation'))
result=dict(passed=all(x['passed'] for x in checks),checks=len(checks),failures=[x for x in checks if not x['passed']],reports=reports,assertions=checks)
a.out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k not in ('assertions','reports')},ensure_ascii=False));sys.exit(0 if result['passed'] else 1)
