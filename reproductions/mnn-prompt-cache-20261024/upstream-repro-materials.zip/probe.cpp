#define NOMINMAX
#include <windows.h>
#ifdef NO_ERROR
#undef NO_ERROR
#endif
#include <llm/llm.hpp>
#include <fstream>
#include <sstream>
#include <iostream>
#include <memory>
#include <iomanip>
using namespace MNN::Transformer;
static void emitJsonString(const std::string& s) {
    std::cout<<'"';
    for(unsigned char c:s) {
        if(c=='"'||c=='\\')std::cout<<'\\'<<char(c);
        else if(c=='\n')std::cout<<"\\n";
        else if(c=='\r')std::cout<<"\\r";
        else if(c=='\t')std::cout<<"\\t";
        else if(c<32)std::cout<<"\\u"<<std::hex<<std::setw(4)<<std::setfill('0')<<int(c)<<std::dec;
        else std::cout<<char(c);
    }
    std::cout<<'"';
}
static void vec(const std::vector<int>& a) {std::cout<<'[';for(size_t i=0;i<a.size();++i){if(i)std::cout<<',';std::cout<<a[i];}std::cout<<']';}
static void state(Llm& llm,const char* stage) {
    const auto c=llm.getContext();std::cout<<"{\"kind\":\"state\",\"stage\":";emitJsonString(stage);
    std::cout<<",\"previous\":"<<llm.getCurrentHistory()<<",\"all_seq_len\":"<<c->all_seq_len<<",\"gen_seq_len\":"<<c->gen_seq_len<<",\"prompt_len\":"<<c->prompt_len<<",\"status\":"<<int(c->status)<<",\"current_token\":"<<(std::string(stage)=="before_first"?"null":std::to_string(c->current_token))<<",\"history\":";vec(c->history_tokens);std::cout<<",\"output\":";vec(c->output_tokens);std::cout<<",\"text\":";emitJsonString(c->generate_str);std::cout<<"}\n"<<std::flush;
}
static void prompt(Llm& llm,const ChatMessages& messages,const char* stage) {
    auto text=llm.apply_chat_template(messages);auto tokens=llm.tokenizer_encode(text);
    std::cout<<"{\"kind\":\"prompt\",\"stage\":";emitJsonString(stage);std::cout<<",\"messages\":[";
    for(size_t i=0;i<messages.size();++i){if(i)std::cout<<',';std::cout<<'[';emitJsonString(messages[i].first);std::cout<<',';emitJsonString(messages[i].second);std::cout<<']';}
    std::cout<<"],\"rendered\":";emitJsonString(text);std::cout<<",\"tokens\":";vec(tokens);std::cout<<"}\n"<<std::flush;
}
int main(int argc,char** argv) {
    if(argc!=4)return 64;
    wchar_t dll[32768];char utf8[131072];DWORD len=GetModuleFileNameW(GetModuleHandleW(L"MNN.dll"),dll,32768);if(!len||len>=32768)return 65;int n=WideCharToMultiByte(CP_UTF8,0,dll,len,utf8,131072,nullptr,nullptr);if(!n)return 66;
    std::cout<<"{\"kind\":\"loaded_dll\",\"path\":";emitJsonString(std::string(utf8,n));std::cout<<"}\n";
    std::unique_ptr<Llm> llm(Llm::createLLM(argv[1]));if(!llm||!llm->load())return 67;
    std::ifstream patch(argv[2]);std::ostringstream json;json<<patch.rdbuf();if(!patch.good()&&!patch.eof())return 68;if(!llm->set_config(json.str()))return 69;
    std::cout<<"{\"kind\":\"effective_config\",\"config\":";emitJsonString(llm->dump_config());std::cout<<"}\n";
    bool cap=std::string(argv[3])=="cap";ChatMessages messages={{"user",cap?"What is 2 + 10? Answer only with the number.":"Reply with exactly the word hello."}};
    state(*llm,"before_first");prompt(*llm,messages,"first");std::ostringstream first;llm->response(messages,&first,"",cap?1:64);state(*llm,"after_first");
    auto c=llm->getContext();if(c->status!=LlmStatus::NORMAL_FINISHED&&c->status!=LlmStatus::MAX_TOKENS_FINISHED)return 70;
    messages.emplace_back("assistant",c->generate_str);messages.emplace_back("user","What was my previous question? Give a short answer.");
    state(*llm,"before_second");prompt(*llm,messages,"second");std::ostringstream second;llm->response(messages,&second,"",1);state(*llm,"after_second");
    c=llm->getContext();if(c->status!=LlmStatus::NORMAL_FINISHED&&c->status!=LlmStatus::MAX_TOKENS_FINISHED)return 71;
    std::cout<<"{\"kind\":\"probe_final\",\"requests\":2,\"status\":"<<int(c->status)<<"}\n"<<std::flush;return 0;
}
