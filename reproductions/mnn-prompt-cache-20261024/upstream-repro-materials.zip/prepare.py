"""Prepare only: no inference, no downloads, no model copies."""
import argparse,json
import hashlib
from pathlib import Path
from preconditions import reject_unsupported
p=argparse.ArgumentParser();p.add_argument('--model',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
model=a.model.resolve();out=a.out.resolve()
config=json.loads((model/'config.json').read_text(encoding='utf-8'))
model_config=json.loads((model/'llm_config.json').read_text(encoding='utf-8'))
reject_unsupported(config);reject_unsupported(model_config)
manifest=json.loads((Path(__file__).parent/'resource-manifest.json').read_text(encoding='utf8'))
for entry in manifest['model_files']:
    resource=model/entry['file']
    if resource.stat().st_size!=entry['size'] or hashlib.sha256(resource.read_bytes()).hexdigest()!=entry['sha256']:
        raise ValueError('unsupported model resource identity: '+entry['file'])
jinja=model_config['jinja']
jinja.setdefault('context',{})['enable_thinking']=False
config.update(base_dir=model.as_posix()+'/',backend_type='cpu',sampler_type='greedy',precision='high',thread_num=1,reuse_kv=True,prompt_cache=True,max_new_tokens=64,max_all_tokens=1024,chunk=0)
config['async']=False
patch=dict(jinja=jinja,reuse_kv=True,prompt_cache=True,chunk=0,max_all_tokens=1024)
patch['async']=False
for case in ['cap','eos']:
 d=out/case;d.mkdir(parents=True,exist_ok=False)
 (d/'config.json').write_text(json.dumps(config,ensure_ascii=False,indent=2),encoding='utf-8')
 (d/'runtime-patch.json').write_text(json.dumps(patch,ensure_ascii=False,indent=2),encoding='utf-8')
print('Prepared cap/eos configurations only; inference not started.')
